
#include<ctype.h>
#include<stdio.h>
#include<string.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<stdlib.h>
int main(int argc,char **argv)
{
	int newsocket,welcomesocket;
	char buffer[1024];
	struct sockaddr_in serverAdd;
	struct sockaddr_storage serverStorage;
	socklen_t addr_size;

	welcomesocket=socket(PF_INET,SOCK_STREAM,0);
	serverAdd.sin_family=AF_INET;
	serverAdd.sin_port=htons(atoi(argv[2]));
	serverAdd.sin_addr.s_addr=inet_addr(argv[1]);
	
	memset(serverAdd.sin_zero,'\0',sizeof serverAdd.sin_zero);
	bind(welcomesocket,(struct sockaddr*)&serverAdd,sizeof serverAdd);
	if(listen(welcomesocket,5)==0)
		printf("listening...\n");
	else
		printf("error.\n");
	

	addr_size=sizeof(serverStorage);
	newsocket=accept(welcomesocket,(struct sockaddr*)&serverStorage,&addr_size);
		
	
	
	recv(newsocket,buffer,1024,0);
	printf("server :MESSAGE RECEIVED FROM THE CLIENT :%s\n",buffer);
	int i,len=strlen(buffer);
	for(i=0;i<len;i++)
	{
		if(isupper(buffer[i]))
			buffer[i]=tolower(buffer[i]);
		else
			buffer[i]=toupper(buffer[i]);


	}
	printf("server :TOGGLED MESSAGE - %s SENT BACK\n",buffer);
	send(newsocket,buffer,strlen(buffer),0);
	
	return 0;
}
	
	
