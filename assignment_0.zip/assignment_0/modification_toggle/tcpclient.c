#include<stdio.h>
#include<string.h>
#include<arpa/inet.h>
#include<sys/socket.h>
int main()
{
	int clientsocket;
	char buffer[1024];
	struct sockaddr_in serverAdd;
	
	socklen_t addr_size;

	clientsocket=socket(PF_INET,SOCK_STREAM,0);
	serverAdd.sin_family=AF_INET;
	serverAdd.sin_port=htons(8000);
	serverAdd.sin_addr.s_addr=inet_addr("127.0.0.1");
	
	memset(serverAdd.sin_zero,'\0',sizeof serverAdd.sin_zero);
	connect(clientsocket,(struct sockaddr*)&serverAdd,sizeof serverAdd);
	printf("Enter the string: ");
	scanf("%s",buffer);
	printf("client: SENDING MESSAGE TO SERVER....\n");
	send(clientsocket,buffer,strlen(buffer),0);
	
	
	recv(clientsocket,buffer,1024,0);
	printf("client: ECHO MESSAGE RECEIVED FROM THE SERVER:%s\n",buffer);

	
	return 0;
}
	
	
