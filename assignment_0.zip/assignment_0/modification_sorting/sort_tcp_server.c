

#include<stdio.h>
#include<string.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<stdlib.h>
void sort(int *arr,int n)
{
	int i,j,temp;
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if(arr[j]>arr[j+1])
			{
				temp=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=temp;
			}
		}
	}
}




int main()
{
	int newsocket,welcomesocket;
	char buffer[1024];
	struct sockaddr_in serverAdd;
	struct sockaddr_storage serverStorage;
	socklen_t addr_size;

	welcomesocket=socket(PF_INET,SOCK_STREAM,0);
	serverAdd.sin_family=AF_INET;
	serverAdd.sin_port=htons(8000);
	serverAdd.sin_addr.s_addr=inet_addr("127.0.0.1");
	
	memset(serverAdd.sin_zero,'\0',sizeof serverAdd.sin_zero);
	bind(welcomesocket,(struct sockaddr*)&serverAdd,sizeof serverAdd);
	if(listen(welcomesocket,5)==0)
		printf("listening...\n");
	else
		printf("error.\n");
	

	addr_size=sizeof(serverStorage);
	newsocket=accept(welcomesocket,(struct sockaddr*)&serverStorage,&addr_size);
	int arr[100];int index=0;
	int num,sum=0;
	while(1)
	{
	recv(newsocket,buffer,1024,0);
	if(strcmp(buffer,"n")==0)
		break;
	num=atoi(buffer);
	arr[index++]=num;
	
	}
	sort(arr,index);
	int i=0;
	for(i=0;i<index;i++)
		printf("%d",arr[i]);
	//send(newsocket,buffer,strlen(buffer),0);
	
	return 0;
}
	
	
