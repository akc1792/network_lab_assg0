#include<stdio.h>
#include<string.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<ctype.h>
int main()
{
	int clientsocket;
	char buffer[1024];
	struct sockaddr_in serverAdd;
	
	socklen_t addr_size;

	clientsocket=socket(PF_INET,SOCK_STREAM,0);
	serverAdd.sin_family=AF_INET;
	serverAdd.sin_port=htons(8000);
	serverAdd.sin_addr.s_addr=inet_addr("127.0.0.1");
	
	memset(serverAdd.sin_zero,'\0',sizeof serverAdd.sin_zero);
	connect(clientsocket,(struct sockaddr*)&serverAdd,sizeof serverAdd);
	
	
	int f=1;
	while(f)
           {
		printf("Enter the digits :");
		scanf("%s",buffer);
             if(!isdigit(buffer[0]))
                 break; 
 	send(clientsocket,buffer,strlen(buffer),0);
	    }
	
	return 0;
}
	
	
