

#include<stdio.h>
#include<string.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<ctype.h>

int main()
{
	int newsocket,welcomesocket;
	char buffer[1024];
	struct sockaddr_in serverAdd;
	struct sockaddr_storage serverStorage;
	socklen_t addr_size;

	welcomesocket=socket(PF_INET,SOCK_STREAM,0);
	serverAdd.sin_family=AF_INET;
	serverAdd.sin_port=htons(8000);
	serverAdd.sin_addr.s_addr=inet_addr("127.0.0.1");
	
	memset(serverAdd.sin_zero,'\0',sizeof serverAdd.sin_zero);
	bind(welcomesocket,(struct sockaddr*)&serverAdd,sizeof serverAdd);
	if(listen(welcomesocket,5)==0)
		printf("listening...\n");
	else
		printf("error.\n");
	

	addr_size=sizeof(serverStorage);
	newsocket=accept(welcomesocket,(struct sockaddr*)&serverStorage,&addr_size);
		
	
	
	recv(newsocket,buffer,1024,0);
        printf("server :MESSAGE RECEIVED FROM THE CLIENT :%s\n",buffer);
        int len,i;
        len=strlen(buffer);
        for(i=0;i<len;i++)
                buffer[i]=toupper(buffer[i]);          
	printf("server :RECEIVED MESSAGE ECHOED BACK %s\n",buffer);
	send(newsocket,buffer,strlen(buffer),0);
	
	return 0;
}
	
	
