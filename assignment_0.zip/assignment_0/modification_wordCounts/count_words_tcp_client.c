#include<stdio.h>
#include<string.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<stdlib.h>
int main(int argc,char **argv)
{
	int clientsocket;
	char buffer[1024];
	struct sockaddr_in serverAdd;
	
	socklen_t addr_size;

	clientsocket=socket(PF_INET,SOCK_STREAM,0);
	serverAdd.sin_family=AF_INET;
	serverAdd.sin_port=htons(atoi(argv[2]));
	serverAdd.sin_addr.s_addr=inet_addr(argv[1]);
	
	memset(serverAdd.sin_zero,'\0',sizeof serverAdd.sin_zero);
	connect(clientsocket,(struct sockaddr*)&serverAdd,sizeof serverAdd);
	printf("Enter a sentence :");
	scanf("%[^\n]s",buffer);
	printf("client: SENDING MESSAGE TO SERVER....\n");
	
	send(clientsocket,buffer,strlen(buffer),0);
	
	

	
	return 0;
}
	
	
